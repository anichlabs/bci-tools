# ODL-BCI
ODL-BCI: Optimal deep learning model for brain-computer interface to classify students concentration via hyper-parameter tuning
